/* trigger pe tabela orderdetails; cand se sterg inregistrari din tabela sa se verifice daca s-a sters o comanda integral si, 
in caz afirmativ, sa se modifice statusul comenzii respective
in Deleted, iar numarul comenzii si data cand s-a efectuat stergerea sa fie introduse intr-o tabela denumita istoric;
de asemenea, la fiecare stergere sa se refaca stocul produselor eliminate de pe comanda ( pe tabela de products)*/	

/* creare tabela istoric */
CREATE DATABASE curs8_30Ian;
USE curs8_30Ian;

CREATE TABLE Studenti ( student_id INT PRIMARY KEY,
nume VARCHAR(50),
prenume VARCHAR(50),
data_inscriere DATE ,
examene_admise INT 
);
CREATE TABLE student_details ( student_id INT ,
Absolvent VARCHAR(50),
Casatorit VARCHAR(50) );

INSERT INTO Studenti VALUES ( 1,'ION','ION','2014-09-01',4),( 2,'Alexandru','Maria','2015-09-01',6),
( 3,'Halep','Simona','2016-09-01',5),(4,'Iantu','Virgil','2013-09-01',8);
INSERT INTO student_details VALUES (1,'No','No'),(2,'No','No'),(3,'No','No'),(4,'No','Yes');


