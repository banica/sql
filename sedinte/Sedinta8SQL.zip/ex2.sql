/*2.Trigger pe tabele de studenti care sa verifice daca :
      --Daca s-a updatat coloana de examene admise si aceasta a ajuns la 12 sa marcheze studentul ca absolvent.
	  --Daca studentului i-a fost updatat numele de familie sa il marcam ca si casatorit*/
  use curs8_30ian;    
      
      delimiter \\
create trigger ex2 after update on studenti

                for each row 
                
                  begin 
                  
               if new.examene_admise <> old.examene_admise  and new.examene_admise =12 then 
               
                  update student_details set absolvent ='yes'  where student_id = new.student_id;
                  
                  end if;
                  
                  if new.nume <> old.nume then 
                  
                  
                  update student_details set casatorie ='yes' where student_id=new.student_id;
                  
                  end if;
                  
                  end \\
                  
                  