use classicmodels;
/* trigger pe tabela orderdetails; cand se sterg inregistrari din tabela sa se verifice daca s-a sters o comanda integral si, 
in caz afirmativ, sa se modifice statusul comenzii respective
in Deleted, iar numarul comenzii si data cand s-a efectuat stergerea sa fie introduse intr-o tabela denumita istoric;
de asemenea, la fiecare stergere sa se refaca stocul produselor eliminate de pe comanda ( pe tabela de products)*/
	
select * from orderdetails;
select * from products;
delimiter \\
create trigger ex1 after delete on orderdetails 

                for each row 
                
                  begin 
                  
                  declare var1 int;
                  select count(*) into var1  from orderdetails where ordernumber=old.ordernumber;
                  if var1=0 then
				  update orders set status='deleted' where ordernumber=old.ordernumber;
                  insert into istoric values (old.ordernumber,current_date());
                  end if;
                  update products
                  set quantityinstock=quantityinstock+old.quantityordered
                  where productcode=old.productcode;
                  end \\
                  
				 
                      