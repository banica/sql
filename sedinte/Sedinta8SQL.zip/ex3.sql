/*3.https://dev.mysql.com/doc/refman/5.7/en/error-messages-server.html
Posibile erori .si cum functioneaza cazurile de exceptie ( exemple Oracle ) */
USE COMPANY;
DELIMITER $$
CREATE PROCEDURE test()
BEGIN
DECLARE table_not_found CONDITION for 1146;
DECLARE EXIT HANDLER FOR  table_not_found SELECT 'Please create table abc first';
SELECT * FROM abc;
select * from jobs;
END$$


DELIMITER $$
CREATE PROCEDURE test2()
BEGIN
DECLARE table_not_found CONDITION for 1146;
DECLARE continue HANDLER FOR  table_not_found set @var:='Test';
SELECT * FROM abc;
select * from jobs;
END$$

