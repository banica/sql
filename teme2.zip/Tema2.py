# TEMA2
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program care sa calculeze a si b float aplicate urmatoarei functii matematice: {6*[2+(a-1)%b]*2a}

a = raw_input("Introduceti primul numar:\n")
b = raw_input("Introduceti al doilea numar:\n")
if (a.replace(".","").isdigit() and b.replace(".","").isdigit()):
    a=float(a)
    b=float(b)
    print "raspunsul calculat este: ",(6*(2+(a-1)%b)*2*a)

raw_input("\n\nApasa <enter> pt a iesi.")
