# TEMA7
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program meniu
print """
1 – Afisare lista de cumparaturi
2 – Adaugare element
3 – Stergere element
4 – Sterere lista de cumparaturi
5 - Cautare in lista de cumparaturi"""

a = raw_input("Introduceti un numar:\n")
if a.isdigit():
    a=int(a)
    if a==1:
      print "Afisare lista de cumparaturi"
    elif a==2:
        print "Adaugare element"
    elif a==3:
        print "Stergere element"
    elif a==4:
        print "Sterere lista de cumparaturi"
    elif a==5:
        print "Cautare in lista de cumparaturi"
    else:
        print "Alegerea nu exista.Reincercati"
else:
    print "Sirul introdus nu este un numar"

raw_input("\n\nApasa <enter> pt a iesi.")

