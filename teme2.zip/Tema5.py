# TEMA5
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program  an bisect

a = raw_input("Introduceti un an:\n")
if a.isdigit():
    a=int(a)
    if (not a%4 and a%100) or (not a%400):
        print "Anul",a," este bisect"
    else:
        print "Anul",a,"nu este bisect"

raw_input("\n\nApasa <enter> pt a iesi.")
