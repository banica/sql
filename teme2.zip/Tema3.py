# TEMA3
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program  nr par sau impar

a = raw_input("Introduceti un numar:\n")
if a.isdigit():
    a=int(a)
    if (not a%2):
        print "Numarul",a,"este par"
    else:
        print "Numarul",a," nu este par"

raw_input("\n\nApasa <enter> pt a iesi.")
