# TEMA6
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program  numar -testare if in if cu if-elif-else

a = raw_input("Introduceti un numar:\n")
if a.replace("-","").isdigit():
    a=int(a)
    if a<0:
        a=a*-1
        print "Numarul este ",a
    elif a==0:
        print "numarul este 0"
    else:
        if x>10:
            print "numar mai mare ca 10"
        else:
            print "numar intre 0 si 10"
else:
    print "Sirul introdus nu este un numar"

raw_input("\n\nApasa <enter> pt a iesi.")
