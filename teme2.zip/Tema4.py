# TEMA4
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#Creati un program  ce cauta un cuvant

a = raw_input("Introduceti o fraza:\n")
if "este" in a:
    print "Cuvantul <<este>> exista in sirul de caractere: ",a
    if a.endswith("!") or a.endswith(".") or a.endswith("?"):
        print "Avem semn de punctuatie la finalul sirului:",a
    else:
        print "Nu avem semn de punctuatie la finalul sirului:",a
else:
    print "Cuvantul <<este>> nu exista in sirul de caractere: ",a

raw_input("\n\nApasa <enter> pt a iesi.")
