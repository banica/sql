# TEMA4
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03


##Creati un program in care utilizatorul sa introduca un numar de telefon. Acesta
##trebuie sa introduca un numar cu formatul de 10 cifre si sa inceapa cu 07 (zero
##sapte). Realizati acest program cu ajutorul unui if in if astfel. In cazul in care
##trece de aceste verificari atunci afisati mesajul <<Felicitari! Numarul e
##acceptat.>>

tel=raw_input("Introduceti un numar de telefon\t")

if  (tel.isdigit()):
    if (tel[:2]=="07")
        if(len(tel)==10):
            print "Felicitari! Numarul e acceptat."
        else:
            print "Lungimea sirului nu este 10"
    else:
        print "Sirul nu incepe cu 07"
else:
    print "Sirul nu e format exclusiv din cifre"
            
