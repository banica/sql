# TEMA3.1
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03

#  Creati un program ce are ca scop sortarea a x elemente 
#  introduse de utilizator de la tastatura printr-o bucla while.

print "\n\t\t\tTema sedinta 3.1\n"

lista = []
iteratii = 0

#  De asemenea utilizatorul are datoria sa insereze la inceputul
#  programului cate elemente doreste sa insereze in lista.
nr = raw_input("Tastati nr. de elemente ale listei:\n")
nr = int(nr)

#  Elementele vor fi inserate pe rand intr-o lista prin acest while 
#  de catre utilizator prin capturare de text.

while(iteratii<nr):
    element_lista = (raw_input('Urmatorul element in lista:'))
    lista.append(element_lista)
    iteratii += 1

#  Creati un program ce are ca scop sortarea a x elemente 
#  introduse de utilizator de la tastatura printr-o bucla while.
lista.sort()

#Trebuie sa afisam lista la final.
print lista
