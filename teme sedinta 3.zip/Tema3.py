# TEMA3
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03


##Creati un program cu o lista de CD/DVD-uri utilizand liste nested. Trebuie ca programul sa imite lista de cumparaturi prezentata in curs(fisierul Lista_avansat.py  ca si facilitati (adaugare, stergere, afisare, iesire din program). 
##Fiecare ement din lista trebuie sa fie format dintr-o lista care sa contina urmatoarele elemente introduse de utilizator:
##Titlu – sir de caractere
##Continut – sir de caractere
##Nu permiteti adaugarea a doua intrari cu un titlu identic.
##La afisarea unei intrari a listei creati o afisare pe rand a fiecarui element din lista nested
##Pe langa facilitatile indicate mai sus (adaugare, stergere, afisare, iesire din program) adaugati posbilitatea de a cauta o intrare dupa unui sir de caractere dupa Titlu si Continut.


list_DVD = []

meniu =  ''' Tasteaza:
0-Pentru afisare lista de CD/DVD-uri
1 pentru a adauga un element in lista de CD/DVD-uri
2 pentru a sterge un element existent in lista de CD/DVD-uri
3 pentru a sterge lista de CD/DVD-uri
4 pentru a cauta in lista de CD/DVD-uri
q pentru a iesi
'''


while(True):
    print meniu
    alegere = raw_input('\nTe rog introdu o optiune:\n')
    
    if(alegere == "0"):
        #Afisam lista de CD/DVD-uri
        print "\n"
        iterare=0
        for elem in list_DVD:
            print iterare ,"  => ",elem[0],"\n\t",elem[1]
            # afisam element Titlu si continut
            iterare+=1
        print "\n"
        if (not list_DVD):
            print "\nLista este goala!\n"
        
    elif(alegere == "1"):
        #Adaugam element in lista de CD/DVD-uri
        val1 = raw_input('\nTe rog introdu Titlul: \n')
        val2 = raw_input('\nTe rog introdu Continut: \n')
        i=0 # utilizat pentru cautarea primului element liber
                    
        list_DVD.append([val1,val2])
        print "\nIntrarea adaugata este:"
        print list_DVD[-1][0],"\n\t",list_DVD[-1][1] 
        
    elif(alegere == "2"):
        #Stergere in element
        cheie_temp = raw_input('\nSpecificati numarul asociat elementului pe care doriti sa-l stergeti: \n')

        #Cheia este un numar deci trebuie sa-l convertesc in integer
        if (cheie_temp.isdigit()):
            cheie_temp =int(cheie_temp)
        else:
            cheie_temp = ""
        #list_DVD.keys() returneaza o lista
        if cheie_temp in range(len(list_DVD)):
            del list_DVD[cheie_temp]
        else:
            print "\nNumarul asociat elementului nu este gasit in lista de cumparaturi!\n\
            Va rog reincercati!\n"
    elif(alegere == "3"):
        #Rescriem dictionarul
        list_DVD = []
        print "\nlista a fost stearsa\n"

    elif(alegere == "4"):
        #Cautam in Dictionar
        cauta = raw_input('\nTe rog introdu un cuvant cautat:\n')
        print "\nCautarea a returnat:"
        i=0 # utilizat daca nu gaseste nimic
        for elem in list_DVD:
            if((elem[0].find(cauta)!=-1)or(elem[1].find(cauta)!=-1)):
                print elem[0],"\n\t",elem[1]
                i+=1
        if(i==0):
            print "Nici un rezultat!\n"
        else:
            print "" # cu rol vizual
                  
    elif(alegere == "q"):
        break
    else:
        print "Optiunea aleasa nu este valida! \n"


raw_input("\nVa multumim ca ati ales acest program!\n")



