# TEMA5
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03


##Creati un program in care utilizatorul sa introduca o adresa de email de formatul
##litere_sau_cifre@litere_sau_cifre.litere. Validati acest sir de caractere si informati
##utilizatorul de raspuns.
##@ sau .(punct) trebuie sa exista o singura data in sirul de caractere

email=raw_input("Introduceti o adresa de email\t")
split_after_arond=email.split('@')
split_after_point=email.split('.')
if  ((len(split_after_arond)==2) and len(split_after_point)==2):
    if (split_after_arond[0].isalnum() and split_after_arond[1].replace(".","").isalnum()):
        if(split_after_point[1].isalpha()):
            print "Felicitari! Adresa de email e acceptata."
        else:
            print " Adresa de email nu are domeniul valid. Exista caractere interzise in top level domain"
    else:
        print "Adresa de email nu are domeniul valid"
else:
    print "Adresa de email nu are domeniul valid deoare ce are mai multe puncte sau mai multe @"
            
