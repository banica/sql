# TEMA2
# Demonstreaza cunostintele acumulate
# Ion Studentul 1/13/03
elem=0
sir=raw_input("Srie un sir\t")

for e in sir:
    elem+=1

print "Numarul de caractere ce formeaza sirul este :",elem
